import { CheckmailPipe } from './checkmail.pipe';

describe('CheckmailPipe', () => {
  it('create an instance', () => {
    const pipe = new CheckmailPipe();
    expect(pipe).toBeTruthy();
  });
});
