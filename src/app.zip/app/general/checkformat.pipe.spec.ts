import { CheckformatPipe } from './checkformat.pipe';

describe('CheckformatPipe', () => {
  it('create an instance', () => {
    const pipe = new CheckformatPipe();
    expect(pipe).toBeTruthy();
  });
});
